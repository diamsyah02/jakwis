import { atom } from 'jotai'

export const putFullname = atom('Guest')
export const putID = atom(0)