export const colorPrimary = `#1DA1F2`
export const colorDark = `#14171A`
export const colorGray = `#657786`
export const colorLightGray = `#AAB8C2`
export const colorLight = `#ffffff`
export const colorRed = `#FF0000`

export const KEY_AUTH = `AUTH_JAKWIS`
export const BASE_URL = `https://jakwis.diamsyahh.com/`